_var = {'chrome_driver_path': '/home/aahnik/Downloads/Applications/chromedriver',
        'mBox': '/html/body/div/div/div/div[4]/div/footer/div[1]/div[2]/div/div[2]',
        'mainScreenLOaded': '._3FRCZ',
        'personLoaded': '//*[@id="main"]/header/div[2]/div/div/span[contains(@title,"{name}")]',
        'searchSelector': '.cBxw- > div:nth-child(2)',
        'whatsapp_web_url': 'https://web.whatsapp.com/'
        }
