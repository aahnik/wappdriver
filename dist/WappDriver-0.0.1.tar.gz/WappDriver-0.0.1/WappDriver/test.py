from .whatsWeb import Wapp

wa = Wapp()
wa.send_message("Baba", "hello testing")
